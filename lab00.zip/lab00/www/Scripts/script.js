
function somar() 
{ 
let num1 = document.getElementById("firstNumber").value;
let num2 = document.getElementById("secondNumber").value;
document.getElementById("resultado").innerHTML = parseInt(num1) + parseInt(num2);

}

function subtrair() 
{ 
let num1 = document.getElementById("firstNumber").value;
let num2 = document.getElementById("secondNumber").value;
document.getElementById("resultado").innerHTML = parseInt(num1) - parseInt(num2);

}

function altera() 
{ 

document.getElementById("resultado").style.backgroundColor = "blue";
document.getElementById("resultado").style.fontSize="10px"; 

}

function quadrado(){
    let num1 = document.getElementById("Number").value;
    let num2 = document.getElementById("Number").value;
    document.getElementById("resultado").innerHTML = parseInt(num1) * parseInt(num2);
}
